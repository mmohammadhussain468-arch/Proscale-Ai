"""Central settings for ProScale AI. Change numbers here, everything else follows."""

TICK_SECONDS = 5          # 1 "tick" = 5 seconds of traffic
WINDOW = 30               # LSTM looks at last 30 ticks (2.5 min)
HORIZON = 6               # LSTM predicts the peak of the next 6 ticks (30 sec)
RPS_SCALE = 100.0         # fixed normalisation constant (requests/sec)

CAPACITY_PER_POD = 9.0    # requests/sec one pod can safely serve (250m CPU, 20ms work)
HEADROOM = 1.15           # keep 15% spare capacity
MIN_REPLICAS = 1
MAX_REPLICAS = 8
SCALE_DOWN_PATIENCE = 6   # ticks to wait before removing pods (avoids flapping)

DEPLOYMENT = "proscale-app"
PROM_URL = "http://localhost:9090"
SLA_MS = 500              # a request slower than this counts as an SLA violation
REQUEST_TIMEOUT_S = 5
