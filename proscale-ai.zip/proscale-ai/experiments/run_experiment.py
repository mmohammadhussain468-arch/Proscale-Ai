"""Runs ONE full experiment (about 22 minutes).
   python experiments/run_experiment.py --mode reactive     (normal Kubernetes HPA)
   python experiments/run_experiment.py --mode predictive   (ProScale AI, LSTM)
Both modes replay the exact same traffic, so the comparison is fair."""
import argparse
import os
import subprocess
import sys
import time

import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from config import DEPLOYMENT, PROM_URL, TICK_SECONDS

RESULTS = os.path.join(ROOT, "results")
os.makedirs(RESULTS, exist_ok=True)


def sh(*args, input=None, check=False):
    r = subprocess.run(["kubectl", *args], capture_output=True, text=True,
                       input=input, encoding="utf-8", errors="ignore")
    if check and r.returncode != 0:
        sys.exit(f"kubectl {' '.join(args)} failed:\n{r.stderr}")
    return r.stdout.strip()


def wait_prometheus(timeout=90):
    for _ in range(timeout):
        try:
            if requests.get(f"{PROM_URL}/-/ready", timeout=2).status_code == 200:
                return
        except Exception:
            pass
        time.sleep(1)
    sys.exit("Prometheus not reachable on localhost:9090. Is `kubectl get pods` showing prometheus Running?")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["reactive", "predictive"], required=True)
    ap.add_argument("--ticks", type=int, default=240, help="240 ticks = 20 minutes")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    mode = args.mode

    if mode == "predictive" and not os.path.exists(os.path.join(ROOT, "models", "lstm.keras")):
        sys.exit("models/lstm.keras not found. Run:  python ml/train_lstm.py")

    print(f"=== {mode.upper()} experiment ===")
    sh("apply", "-f", os.path.join(ROOT, "k8s", "app.yaml"), check=True)
    sh("delete", "job", "loadgen", "--ignore-not-found")
    sh("delete", "hpa", "proscale-hpa", "--ignore-not-found")   # remove HPA so it can't fight our scaler
    sh("scale", "deploy", DEPLOYMENT, "--replicas=1")
    print("Waiting for 1 healthy pod...")
    sh("rollout", "status", f"deploy/{DEPLOYMENT}", "--timeout=180s")
    time.sleep(20)  # let extra pods from the previous run terminate

    if mode == "reactive":
        sh("apply", "-f", os.path.join(ROOT, "k8s", "hpa.yaml"), check=True)
        print("Normal HPA enabled.")

    pf = subprocess.Popen(["kubectl", "port-forward", "svc/prometheus", "9090:9090"],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    scaler = None
    try:
        wait_prometheus()
        timeline = os.path.join(RESULTS, f"{mode}_timeline.csv")
        scaler = subprocess.Popen([sys.executable, os.path.join(ROOT, "predictor", "scaler.py"),
                                   "--mode", "predictive" if mode == "predictive" else "observe",
                                   "--out", timeline], cwd=ROOT)
        time.sleep(15)

        job = open(os.path.join(ROOT, "k8s", "loadgen-job.yaml")).read()
        job = job.replace("__TICKS__", str(args.ticks)).replace("__SEED__", str(args.seed))
        sh("apply", "-f", "-", input=job, check=True)
        print(f"Load test started ({args.ticks * TICK_SECONDS / 60:.0f} min). Watch live:  kubectl get pods -w")

        deadline = time.time() + args.ticks * TICK_SECONDS + 400
        while time.time() < deadline:
            if sh("get", "job", "loadgen", "-o", "jsonpath={.status.succeeded}") == "1":
                break
            if sh("get", "job", "loadgen", "-o", "jsonpath={.status.failed}") not in ("", "0"):
                print("Load job FAILED. Check:  kubectl logs job/loadgen")
                break
            time.sleep(10)
        time.sleep(10)

        logs = sh("logs", "job/loadgen")
        lines = [l for l in logs.splitlines() if l.startswith("RESULT")]
        if len(lines) < 100:
            print("WARNING: very few results. Output was:\n", logs[-1500:])
        out = os.path.join(RESULTS, f"{mode}_requests.csv")
        with open(out, "w") as fh:
            fh.write("tick,latency_ms,status\n")
            for l in lines:
                if not l.startswith("RESULT_HEADER"):
                    fh.write(l.split(",", 1)[1] + "\n")
        print(f"Saved {out} ({len(lines)-1} requests) and {timeline}")
    finally:
        if scaler:
            scaler.terminate()
        pf.terminate()
        sh("delete", "job", "loadgen", "--ignore-not-found")
        sh("delete", "hpa", "proscale-hpa", "--ignore-not-found")
        sh("scale", "deploy", DEPLOYMENT, "--replicas=1")
    print("Done. Next: run the other mode, then  python experiments/compare.py")


if __name__ == "__main__":
    main()
