"""Reactive (normal HPA) vs Predictive (ProScale AI): metrics table + graphs.
python experiments/compare.py"""
import math
import os
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from config import TICK_SECONDS, CAPACITY_PER_POD, MAX_REPLICAS, SLA_MS, REQUEST_TIMEOUT_S

R = os.path.join(ROOT, "results")


def scale_lag(t):
    """Average seconds between 'surge starts' and 'enough pods are READY for the surge'.
       Negative = pods were ready BEFORE the surge (that is what predictive scaling aims for)."""
    rps = t.rps.rolling(3, min_periods=1).mean().values
    ready = t.ready.fillna(0).values
    thr = 0.5 * rps.max()
    lags, i = [], 0
    while i < len(rps):
        if rps[i] >= thr and (i == 0 or rps[i - 1] < thr):
            need = min(MAX_REPLICAS, math.ceil(rps[i:i + 20].max() / CAPACITY_PER_POD))
            hit = next((j for j in range(max(0, i - 12), min(len(rps), i + 40)) if ready[j] >= need), None)
            lags.append(((hit - i) if hit is not None else 40) * TICK_SECONDS)
            i += 30
        else:
            i += 1
    return float(np.mean(lags)) if lags else float("nan")


def metrics(t, q):
    failed = q.status != 200
    eff = np.where(failed, REQUEST_TIMEOUT_S * 1000, q.latency_ms)   # failed request = timeout
    return {
        "requests": len(q),
        "failed_requests_%": 100 * failed.mean(),
        "SLA_violations_%": 100 * (failed | (q.latency_ms > SLA_MS)).mean(),
        "avg_latency_ms": eff.mean(),
        "p95_latency_ms": np.percentile(eff, 95),
        "p99_latency_ms": np.percentile(eff, 99),
        "under_provisioned_%": 100 * ((t.ready.fillna(0) * CAPACITY_PER_POD) < t.rps).mean(),
        "avg_scaleup_lag_s": scale_lag(t),
        "pod_seconds (cost)": (t.spec * TICK_SECONDS).sum(),
    }


def main():
    data = {}
    for mode in ("reactive", "predictive"):
        try:
            data[mode] = (pd.read_csv(os.path.join(R, f"{mode}_timeline.csv")),
                          pd.read_csv(os.path.join(R, f"{mode}_requests.csv")))
        except FileNotFoundError:
            sys.exit(f"Missing results for '{mode}'. Run: python experiments/run_experiment.py --mode {mode}")

    rows = {m: metrics(*data[m]) for m in data}
    df = pd.DataFrame(rows).round(2)
    imp = []
    for k in df.index:
        a, b = df.loc[k, "reactive"], df.loc[k, "predictive"]
        imp.append(round(100 * (a - b) / a, 1) if k != "requests" and a not in (0, np.nan) and abs(a) > 1e-9 else "")
    df["improvement_%"] = imp
    df.to_csv(os.path.join(R, "comparison.csv"))
    print("\n", df.to_string(), "\n")
    print("improvement_% = how much LOWER predictive is than reactive (positive = ProScale AI better).")
    print("Scale-up lag can be negative or near 0, so read it in seconds, not in %.")

    # ---- graph 1: demand vs capacity
    fig, ax = plt.subplots(2, 1, figsize=(11, 7), sharex=True)
    for a, m, c in zip(ax, ("reactive", "predictive"), ("tab:red", "tab:green")):
        t = data[m][0]
        x = t.t / 60
        a.plot(x, t.rps, color="black", label="Traffic (req/s)")
        a.step(x, t.ready.fillna(0) * CAPACITY_PER_POD, color=c, where="post", label="Capacity (ready pods x per-pod)")
        a.set_title("Reactive HPA (normal Kubernetes)" if m == "reactive" else "ProScale AI (LSTM predictive)")
        a.set_ylabel("req/s"); a.legend(loc="upper left")
    ax[1].set_xlabel("minutes")
    plt.tight_layout(); plt.savefig(os.path.join(R, "capacity_vs_traffic.png"), dpi=130); plt.close()

    # ---- graph 2: key metrics bars
    keys = ["failed_requests_%", "p95_latency_ms", "pod_seconds (cost)", "under_provisioned_%"]
    fig, ax = plt.subplots(1, len(keys), figsize=(13, 3.6))
    for a, k in zip(ax, keys):
        a.bar(["Reactive", "ProScale"], [df.loc[k, "reactive"], df.loc[k, "predictive"]], color=["tab:red", "tab:green"])
        a.set_title(k, fontsize=9)
    plt.tight_layout(); plt.savefig(os.path.join(R, "metrics_comparison.png"), dpi=130); plt.close()
    print("Saved: results/comparison.csv, capacity_vs_traffic.png, metrics_comparison.png")


if __name__ == "__main__":
    main()
