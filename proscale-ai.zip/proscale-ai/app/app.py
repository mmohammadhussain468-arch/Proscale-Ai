"""Tiny web service. Every /work call burns 20ms of CPU so load really needs pods."""
import os
import time
from flask import Flask, Response
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

app = Flask(__name__)
WORK_MS = float(os.getenv("WORK_MS", "20"))

REQS = Counter("http_requests_total", "Total /work requests")
LAT = Histogram("http_request_duration_seconds", "Server side latency",
                buckets=(.025, .05, .1, .25, .5, 1, 2, 5))


@app.route("/work")
def work():
    start = time.perf_counter()
    cpu0 = time.thread_time()
    while time.thread_time() - cpu0 < WORK_MS / 1000.0:
        pass
    REQS.inc()
    LAT.observe(time.perf_counter() - start)
    return "ok"


@app.route("/healthz")
def healthz():
    return "ok"


@app.route("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)
