"""Synthetic but realistic traffic: quiet period -> fast ramp (sale / result day) -> peak -> fall."""
import numpy as np
from config import TICK_SECONDS


def _smooth(n):
    x = np.linspace(0, 1, n)
    return x * x * (3 - 2 * x)  # smoothstep


def generate_trace(n_ticks, seed=0, base=8.0, peak=55.0):
    """Return requests-per-second for each tick (numpy array of length n_ticks)."""
    rng = np.random.default_rng(seed)
    parts = []
    total = 0
    while total < n_ticks:
        b = base * rng.uniform(0.8, 1.3)
        p = peak * rng.uniform(0.75, 1.1)
        low = int(rng.integers(24, 34))
        ramp = int(rng.integers(8, 13))
        hold = int(rng.integers(6, 11))
        fall = int(rng.integers(8, 13))
        seg = np.concatenate([
            np.full(low, b),
            b + (p - b) * _smooth(ramp),
            np.full(hold, p),
            p - (p - b) * _smooth(fall),
        ])
        parts.append(seg)
        total += len(seg)
    trace = np.concatenate(parts)[:n_ticks]
    trace = trace * rng.normal(1.0, 0.06, size=len(trace))
    return np.clip(trace, 1.0, None)


def observed(series, k=3):
    """What Prometheus 'sees': a short causal moving average (rate() smoothing)."""
    series = np.asarray(series, dtype=float)
    out = np.empty_like(series)
    for i in range(len(series)):
        out[i] = series[max(0, i - k + 1): i + 1].mean()
    return out


if __name__ == "__main__":
    t = generate_trace(240, seed=42)
    print("ticks:", len(t), "min/max rps:", t.min().round(1), t.max().round(1),
          "duration min:", len(t) * TICK_SECONDS / 60)
