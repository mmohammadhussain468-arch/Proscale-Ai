# ProScale AI — Predictive Auto-Scaling for Kubernetes

Normal Kubernetes (HPA) scales **after** traffic arrives. ProScale AI uses an **LSTM** to forecast
the next 30 seconds of traffic and adds pods **before** the spike. We run both on the exact same
traffic and compare latency, failed requests and cost.

```
Locust-style load (in cluster) ──► App pods (Flask) ──► Prometheus (scrape every 5s)
                                        ▲                        │
                                        │ kubectl scale          ▼
                              predictor/scaler.py  ◄── last 2.5 min traffic ── LSTM forecast
                                                     (next 30s peak) -> pods needed
```

## Folder map
| Path | Kaam |
|---|---|
| `config.py` | Saare settings (capacity per pod, window, horizon...) |
| `traffic.py` | Traffic generator (quiet → ramp → peak → fall) |
| `ml/train_lstm.py` | LSTM train + baselines (Naive, Moving Avg, ARIMA) compare |
| `predictor/scaler.py` | Live scaler: Prometheus → LSTM → `kubectl scale` |
| `app/app.py` | Demo web app (20ms CPU per request + `/metrics`) |
| `loadgen/loadgen.py` | Load generator (runs as Kubernetes Job) |
| `k8s/` | Deployment, Service, HPA (baseline), Prometheus, Grafana, Job |
| `experiments/run_experiment.py` | Ek command = poora experiment |
| `experiments/compare.py` | Reactive vs Predictive table + graphs |

---

## STEP-BY-STEP (PowerShell, Windows)

### 0. Ek baar install (Docker Desktop, Minikube, kubectl, Python 3.11)
```
wsl --install                      # restart after this
winget install Kubernetes.minikube
winget install Kubernetes.kubectl
winget install Python.Python.3.11
```
Docker Desktop manually install kar (WSL2 backend ON) aur **open rakh**.

### 1. Python environment
```
cd proscale-ai
py -3.11 -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```
> Python 3.12/3.13 mat use kar, TensorFlow nahi chalega. 3.11 hi.

### 2. Kubernetes cluster start
```
minikube start --driver=docker --cpus=4 --memory=6144
minikube addons enable metrics-server
kubectl get nodes
```
`Ready` dikhna chahiye. ✅

### 3. App image build + cluster mein load
```
docker build -f docker/Dockerfile -t proscale-app:latest .
minikube image load proscale-app:latest
```

### 4. Prometheus + Grafana + App deploy
```
kubectl apply -f k8s/monitoring.yaml -f k8s/grafana.yaml -f k8s/app.yaml
kubectl get pods
```
2-3 min mein `prometheus`, `grafana`, `proscale-app` sab `Running` + `1/1` hone chahiye.
(Pehli baar image pull mein time lagta hai.)

### 5. LSTM train karo (5-10 min)
```
python ml/train_lstm.py
```
Output: `models/lstm.keras`, `results/model_metrics.csv` (LSTM vs ARIMA vs baselines), `results/forecast_plot.png`

### 6. Experiment 1 — Reactive (normal HPA), ~22 min
```
python experiments/run_experiment.py --mode reactive
```
Kuch mat chhed, laptop sleep mein mat jaane de. Live dekhna ho to doosre PowerShell mein: `kubectl get pods -w`

### 7. Experiment 2 — Predictive (ProScale AI), ~22 min
```
python experiments/run_experiment.py --mode predictive
```

### 8. Comparison + graphs
```
python experiments/compare.py
```
Output: `results/comparison.csv`, `capacity_vs_traffic.png`, `metrics_comparison.png` → report mein daal.

### 9. Grafana live dashboard (demo ke liye)
Experiment chalte waqt:
```
kubectl port-forward svc/grafana 3000:3000
```
Browser: http://localhost:3000 → Dashboards → **ProScale AI** (login nahi chahiye).

---

## Agar error aaye (common)
| Problem | Fix |
|---|---|
| `ErrImageNeverPull` | Step 3 dobara: `minikube image load proscale-app:latest` |
| `metrics not available` / HPA `<unknown>` | `minikube addons enable metrics-server`, 1-2 min ruk |
| `Prometheus not reachable` | `kubectl get pods` mein prometheus Running hai? Port 9090 free hai? |
| Pods `Pending` | Docker Desktop → Settings → Resources: 6GB+ RAM do, `minikube delete` phir step 2 |
| Bahut zyada failed requests dono mein | `config.py` mein `CAPACITY_PER_POD` 9 → 7 kar do, image rebuild (step 3) nahi chahiye, bas dubara experiment |
| `tensorflow` install fail | Python 3.11 use kar raha hai na? `python --version` check kar |

## IMPORTANT — honest results
- Numbers (latency, failures, cost) **tere apne run se** aayenge. Jo aaye wahi report/resume mein likh.
  25% / 18% sirf target the; real result 12% bhi ho sakta hai, aur wo bhi theek hai.
- Traffic **synthetic** hai (quiet → ramp → peak). Report mein likh: "real traces (Google/Alibaba/Azure)
  se bhi validate kiya ja sakta hai". Real dataset use karna ho to `traffic.py` mein CSV load kar sakte ho.
- Pod "warm-up" 15 sec simulate kiya hai (`readinessProbe`) — real apps mein model/JVM load hone mein
  itna time lagta hi hai. Yahi reactive scaling ka asli dushman hai.
- Experiment ek baar chalaya hai, to 2-3 baar chala ke average le (report mein strong lagta hai).

## Viva ke liye 1-line
> "Kubernetes HPA reactive hai: pehle CPU badhta hai, phir pods bante hain, aur warm-up ke time users
> wait karte hain. Humne LSTM se agle 30 sec ka traffic predict karke pods pehle hi ready kar diye."

## Resume line (X, Y apne results se bharo)
> **ProScale AI – Predictive Auto-Scaling for Kubernetes** | Python, TensorFlow, Kubernetes, Prometheus, Grafana, Docker
> Built an LSTM traffic forecaster that scales pods ahead of load spikes; vs reactive HPA reduced p95 latency by **X%** and failed requests by **Y%**.
