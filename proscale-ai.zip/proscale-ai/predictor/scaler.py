"""The brain of ProScale AI. Runs on your laptop, every 5 seconds:
   1. reads recent traffic from Prometheus
   2. (predictive mode) asks the LSTM what traffic will be in the next 30s
   3. scales the Deployment BEFORE the load arrives
   4. logs a timeline row (used later for graphs + comparison)

   --mode predictive : LSTM scaling
   --mode observe    : only record (used while the normal reactive HPA is doing the scaling)"""
import argparse
import csv
import math
import os
import subprocess
import sys
import time
from collections import deque

import numpy as np
import requests

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from config import (TICK_SECONDS, WINDOW, RPS_SCALE, CAPACITY_PER_POD, HEADROOM,
                    MIN_REPLICAS, MAX_REPLICAS, SCALE_DOWN_PATIENCE, DEPLOYMENT, PROM_URL)

QUERY = "sum(rate(http_requests_total[15s]))"


def prom_history():
    """Last WINDOW observations (requests/sec, one per tick) from Prometheus."""
    end = time.time()
    start = end - WINDOW * TICK_SECONDS
    r = requests.get(f"{PROM_URL}/api/v1/query_range",
                     params={"query": QUERY, "start": start, "end": end, "step": TICK_SECONDS},
                     timeout=5).json()
    res = r.get("data", {}).get("result", [])
    if not res:
        return np.zeros(WINDOW)
    vals = []
    for _, v in res[0]["values"]:
        try:
            x = float(v)
            vals.append(0.0 if math.isnan(x) else x)
        except ValueError:
            vals.append(0.0)
    vals = vals[-WINDOW:]
    if len(vals) < WINDOW:
        vals = [0.0] * (WINDOW - len(vals)) + vals
    return np.array(vals)


def kubectl(*args):
    return subprocess.run(["kubectl", *args], capture_output=True, text=True).stdout.strip()


def get_replicas():
    out = kubectl("get", "deploy", DEPLOYMENT, "-o", "jsonpath={.spec.replicas},{.status.readyReplicas}")
    parts = (out.split(",") + ["0", "0"])[:2]
    return int(parts[0] or 0), int(parts[1] or 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["predictive", "observe"], required=True)
    ap.add_argument("--out", required=True, help="timeline csv path")
    args = ap.parse_args()

    model = None
    if args.mode == "predictive":
        from tensorflow import keras
        model = keras.models.load_model(os.path.join(ROOT, "models", "lstm.keras"))
        print("LSTM loaded. Predictive scaling ON.", flush=True)

    recent_wants = deque(maxlen=SCALE_DOWN_PATIENCE)
    t0 = time.time()
    next_t = t0
    with open(args.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["t", "rps", "forecast", "desired", "spec", "ready"])
        while True:
            try:
                hist = prom_history()
                rps = float(hist[-1])
                forecast, desired = "", ""
                spec, ready = get_replicas()

                if model is not None:
                    x = (hist / RPS_SCALE).astype("float32").reshape(1, WINDOW, 1)
                    forecast = float(model(x, training=False).numpy()[0, 0]) * RPS_SCALE
                    need = max(forecast, rps) * HEADROOM / CAPACITY_PER_POD
                    want = int(min(MAX_REPLICAS, max(MIN_REPLICAS, math.ceil(need))))
                    recent_wants.append(want)
                    desired = want
                    target = spec
                    if want > spec:                       # scale UP immediately
                        target = want
                    elif len(recent_wants) == SCALE_DOWN_PATIENCE:   # scale DOWN slowly
                        target = max(max(recent_wants), MIN_REPLICAS)
                        target = min(target, spec)
                    if target != spec:
                        kubectl("scale", "deploy", DEPLOYMENT, f"--replicas={target}")
                        print(f"[{time.time()-t0:5.0f}s] rps={rps:5.1f} forecast={forecast:5.1f} "
                              f"-> scale {spec} -> {target}", flush=True)

                w.writerow([round(time.time() - t0, 1), round(rps, 2),
                            round(forecast, 2) if forecast != "" else "", desired, spec, ready])
                fh.flush()
            except Exception as e:  # keep running even if one tick fails
                print("tick error:", e, flush=True)
            next_t += TICK_SECONDS
            time.sleep(max(0, next_t - time.time()))


if __name__ == "__main__":
    main()
