"""Train the LSTM forecaster and compare it with simple baselines (naive, moving average, ARIMA).
Run:  python ml/train_lstm.py"""
import os
import sys
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from config import WINDOW, HORIZON, RPS_SCALE
from traffic import generate_trace, observed

os.makedirs(os.path.join(ROOT, "models"), exist_ok=True)
os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)


def make_xy(raw):
    """X = what Prometheus would have seen in the last WINDOW ticks.
       y = the highest real traffic in the next HORIZON ticks."""
    obs = observed(raw)
    X, y = [], []
    for i in range(WINDOW, len(raw) - HORIZON):
        X.append(obs[i - WINDOW:i])
        y.append(raw[i:i + HORIZON].max())
    return np.array(X, dtype="float32"), np.array(y, dtype="float32")


def main():
    import tensorflow as tf
    from tensorflow import keras

    tf.random.set_seed(1)
    np.random.seed(1)

    # ---- data (synthetic daily-pattern traffic; different seeds for train / val / test)
    train_raw = np.concatenate([generate_trace(6000, seed=s) for s in range(1, 6)])
    val_raw = generate_trace(2000, seed=100)
    test_raw = generate_trace(1500, seed=999)
    Xtr, ytr = make_xy(train_raw)
    Xva, yva = make_xy(val_raw)
    Xte, yte = make_xy(test_raw)
    print("samples  train/val/test:", len(Xtr), len(Xva), len(Xte))

    f = lambda X: (X / RPS_SCALE)[..., None]
    model = keras.Sequential([
        keras.layers.Input(shape=(WINDOW, 1)),
        keras.layers.LSTM(32),
        keras.layers.Dense(16, activation="relu"),
        keras.layers.Dense(1),
    ])
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="mae")
    model.fit(f(Xtr), ytr / RPS_SCALE, validation_data=(f(Xva), yva / RPS_SCALE),
              epochs=40, batch_size=128, verbose=2,
              callbacks=[keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)])
    model.save(os.path.join(ROOT, "models", "lstm.keras"))

    # ---- evaluation on unseen test traffic
    lstm_pred = model.predict(f(Xte), verbose=0).ravel() * RPS_SCALE
    naive_pred = Xte[:, -1]
    ma_pred = Xte[:, -6:].mean(axis=1)

    arima_pred = None
    try:
        from statsmodels.tsa.arima.model import ARIMA
        warnings.filterwarnings("ignore")
        idx = np.linspace(0, len(Xte) - 1, 120).astype(int)
        preds = []
        for i in idx:
            try:
                fc = ARIMA(Xte[i], order=(2, 0, 1)).fit().forecast(HORIZON)
                preds.append(max(float(np.max(fc)), float(Xte[i][-1])))
            except Exception:
                preds.append(float(Xte[i][-1]))
        arima_pred = (idx, np.array(preds))
    except ImportError:
        print("statsmodels not installed - skipping ARIMA")

    def row(name, pred, truth):
        err = pred - truth
        return {"model": name, "MAE_rps": np.abs(err).mean(),
                "RMSE_rps": np.sqrt((err ** 2).mean()),
                "under_predict_%": 100 * (err < -5).mean()}

    rows = [row("LSTM (ours)", lstm_pred, yte),
            row("Naive (last value)", naive_pred, yte),
            row("Moving average", ma_pred, yte)]
    if arima_pred is not None:
        idx, p = arima_pred
        rows.append(row("ARIMA(2,0,1)", p, yte[idx]))
    df = pd.DataFrame(rows).round(2)
    df.to_csv(os.path.join(ROOT, "results", "model_metrics.csv"), index=False)
    print("\n", df.to_string(index=False))

    # ---- plot
    n = 300
    plt.figure(figsize=(11, 4))
    plt.plot(yte[:n], label="Actual peak (next 30s)", color="black")
    plt.plot(lstm_pred[:n], label="LSTM forecast", color="tab:blue")
    plt.plot(naive_pred[:n], label="Naive (reactive-like)", color="tab:red", alpha=.5)
    plt.xlabel("tick (5s)"); plt.ylabel("requests/sec"); plt.legend(); plt.title("Traffic forecast vs actual (test data)")
    plt.tight_layout()
    plt.savefig(os.path.join(ROOT, "results", "forecast_plot.png"), dpi=130)
    print("\nSaved: models/lstm.keras, results/model_metrics.csv, results/forecast_plot.png")


if __name__ == "__main__":
    main()
