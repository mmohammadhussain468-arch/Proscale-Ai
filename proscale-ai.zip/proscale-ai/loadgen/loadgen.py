"""Runs INSIDE the cluster as a Job. Replays the traffic trace against the service
and prints one RESULT line per request (tick, latency_ms, status)."""
import asyncio
import os
import time
import aiohttp
from traffic import generate_trace
from config import TICK_SECONDS, REQUEST_TIMEOUT_S

TARGET = os.getenv("TARGET", "http://proscale-app")
TICKS = int(os.getenv("TICKS", "240"))
SEED = int(os.getenv("SEED", "42"))


async def one(session, tick, out):
    t = time.perf_counter()
    try:
        async with session.get(TARGET + "/work") as r:
            await r.read()
            status = r.status
    except Exception:
        status = 0
    out.append((tick, round((time.perf_counter() - t) * 1000, 1), status))


async def main():
    trace = generate_trace(TICKS, SEED)
    out, tasks = [], []
    # force_close = new TCP connection per request, so kube-proxy spreads load over ALL pods
    conn = aiohttp.TCPConnector(limit=0, force_close=True)
    timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT_S)
    async with aiohttp.ClientSession(connector=conn, timeout=timeout) as session:
        t0 = time.perf_counter()
        for tick, rps in enumerate(trace):
            n = max(1, int(round(rps * TICK_SECONDS)))
            for i in range(n):
                at = t0 + tick * TICK_SECONDS + i * TICK_SECONDS / n
                delay = at - time.perf_counter()
                if delay > 0:
                    await asyncio.sleep(delay)
                tasks.append(asyncio.create_task(one(session, tick, out)))
        await asyncio.gather(*tasks)
    print("RESULT_HEADER,tick,latency_ms,status", flush=True)
    for tick, lat, st in out:
        print(f"RESULT,{tick},{lat},{st}")


if __name__ == "__main__":
    asyncio.run(main())
